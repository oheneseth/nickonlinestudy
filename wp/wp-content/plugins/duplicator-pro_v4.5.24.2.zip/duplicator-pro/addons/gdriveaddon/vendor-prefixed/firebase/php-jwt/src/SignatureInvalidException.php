<?php

namespace VendorDuplicator\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
