<?php

namespace VendorDuplicator\Aws\Exception;

/**
 * Class CryptoPolyfillException
 */
class CryptoPolyfillException extends \RuntimeException
{
}
