<?php

namespace VendorDuplicator;

// This file was auto-generated from sdk-root/src/data/sts/2011-06-15/paginators-1.json
return ['pagination' => []];
