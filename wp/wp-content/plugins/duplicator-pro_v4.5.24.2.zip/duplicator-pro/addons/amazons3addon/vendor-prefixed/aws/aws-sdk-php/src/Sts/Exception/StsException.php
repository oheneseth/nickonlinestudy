<?php

namespace VendorDuplicator\Aws\Sts\Exception;

use VendorDuplicator\Aws\Exception\AwsException;
/**
 * AWS Security Token Service exception.
 */
class StsException extends AwsException
{
}
