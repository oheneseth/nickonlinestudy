=== Duplicator - Backups & Migration Plugin - Cloud Backups, Scheduled Backups, & More  ===
Contributors: seedprod, smub, andreamk
Tags: backup, database backup, wordpress backup, cloud backup, migration
Requires at least: 5.3
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 4.5.24.2
License: GPLv2

The best WordPress backup and migration plugin. Quickly and easily backup ,migrate, copy, move, or clone your site from one location to another. Simplify backups & migrations without limits.

== Description ==

= WordPress Backup & Migration Plugin =

[Duplicator PRO](https://duplicator.com) provides a simple way to move WordPress sites, create reliable backups, or clone a site for staging. With Duplicator, you can easily migrate, transfer, or clone your WordPress site between domains or hosts with no downtime. Create full backups of your website, or package your entire site to download and install elsewhere with only a few steps.

At Duplicator, reliabilty, security, and ease of use are our top priorities. Our variety of cloud backup integrations and easy migration wizard make Duplicator the most beginner-friendly backup and migration plugin on the market. You don't have to hire a developer. Create a backup and migrate sites in just a few minutes.

Duplicator Pro comes with scheduled backups, cloud storage integrations, multisite support, and more. 

== Screenshots ==

== Frequently Asked Questions ==

== Changelog ==

Please see the following url:
[https://duplicator.com/knowledge-base/changelog](https://duplicator.com/knowledge-base/changelog)

== Upgrade Notice ==