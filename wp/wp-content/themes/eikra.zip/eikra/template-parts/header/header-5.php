<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 3.1
 */

$nav_menu_args = RDTheme_Helper::nav_menu_args();

?>
<div class="masthead-container">
	<div class="site-branding">
		<?php echo RDTheme_Helper::get_site_logo(); ?>
	</div>
	<?php if ( RDTheme::$options['header_btn_txt'] && RDTheme::$options['header_btn_url'] ): ?>
		<a class="header-menu-btn" href="<?php echo RDTheme::$options['header_btn_url'];?>"><?php echo RDTheme::$options['header_btn_txt'];?></a>
	<?php endif; ?>

    <div id="site-navigation" class="main-navigation">
		<?php wp_nav_menu( $nav_menu_args );?>
	</div>

	<div class="clear"></div>
</div>