<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
global $product;
$product_id = $product->get_id(); 
?>
<div class="product-thumb-area">
	<?php
	woocommerce_show_product_loop_sale_flash();
	woocommerce_template_loop_product_thumbnail();
	?>
	<div class="overlay"></div>
	<div class="product-info">
		<ul>
			<li><?php rdtheme_wc_add_to_cart_icon();?></li>
			<?php  if (  apply_filters( 'rtsb/module/wishlist/show_button', true ) ){ ?>
                <li>
                    <?php  do_action( 'rtsb/modules/wishlist/print_button', $product_id ); ?>
                </li>
            <?php } ?>
            <?php if ( apply_filters('rtsb/module/quick_view/show_button',true) ){ ?>
                <li>
                    <?php  do_action( 'rtsb/modules/quick_view/print_button', $product_id ); ?>
                </li>
            <?php } ?>
		</ul>
	</div>
</div>